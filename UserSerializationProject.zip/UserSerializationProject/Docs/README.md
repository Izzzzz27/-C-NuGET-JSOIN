# user serialization project

This project includes:
- json and xml reading.
- adding new entries to json.
- deserializing data into objects.
- using inheritance for user roles.
- printing results to console.

## steps
1. basic file creation (json/xml)
2. entry addition to json
3. deserialization with loop
4. inheritance use for role types
5. user types deserialization
