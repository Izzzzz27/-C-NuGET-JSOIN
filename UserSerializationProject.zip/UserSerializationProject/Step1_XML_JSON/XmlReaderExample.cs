using System;
using System.Xml;

class XmlReaderExample {
    static void Main() {
        XmlDocument doc = new XmlDocument();
        doc.Load("example.xml");
        XmlNodeList nodes = doc.SelectNodes("/users/user");

        foreach (XmlNode node in nodes) {
            Console.WriteLine("user: " + node["name"].InnerText);
        }
    }
}