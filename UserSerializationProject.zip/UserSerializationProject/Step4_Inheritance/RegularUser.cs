public class RegularUser : User {
    public string role => "user";
}